const e="https://internet-detective-proxy.vercel.app",t="llama-3.3-70b-versatile",a={backend:"hosted",apiEndpoint:e,ollamaUrl:"http://localhost:11434",model:"qwen3:4b",enableLlm:!0,senderName:"",senderRole:"",hunterApiKey:""},s="spectra",n=2;export{a as D,t as H,e as a,s as b,n as c};
//# sourceMappingURL=constants.js.map
