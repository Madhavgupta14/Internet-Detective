const t={ollamaUrl:"http://localhost:11434",model:"qwen3:0.6b",enableLlm:!0},e="internet-detective",a=2;export{t as D,e as a,a as b};
//# sourceMappingURL=constants.js.map
